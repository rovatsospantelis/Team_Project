The aim of the project is to develop an E-Commerce Site where the customer can buy and download online movies. The project is composed of 2 seperate apps, the user - customer (team project folder) and the admin app. The administrator can do CRUD to movies and reply to the users' messages. The user can register/login, browse the movie list and communicate with the administrator. If the user attempts to buy the same movie twice, or if he selects to purchase an unavailable movie the app will notify and prompt him to select something else.

Before running the project open the recourses/application.properties and set the email/password fields, it's essential for the user registration.



                                                   TEAM COMPOSITION: 

                                                 PANTELEIMON ROVATSOS - Team Coordinator 
                                                 GEORGE CHATZINIKOLAOU
                                                 GEORGE KOZAKOS